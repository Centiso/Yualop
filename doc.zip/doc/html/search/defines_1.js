var searchData=
[
  ['p_5fr_89',['P_R',['../commun_8h.html#a1bd2e58a183206537e3365f36d514eec',1,'commun.h']]]
];
